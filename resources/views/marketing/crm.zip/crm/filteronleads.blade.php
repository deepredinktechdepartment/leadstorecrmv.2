<!-- Check if there are any validation errors -->
@php

    use App\Models\ApiCredential;
     $intranet_project = ApiCredential::where('intranet_project_id',$projectID)->get()->first();
     $utmData=$intranet_project->filter_options??'';
     $utmData=json_decode($utmData,true);
     $utmData = is_array($utmData) ? array_filter($utmData) : [];





@endphp
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<!-- Use the Blade directive to check if the form is submitted -->
@if (request()->isMethod('post') || request()->isMethod('get'))
    <!-- Form is submitted, use the old function to retrieve the submitted values -->
    @php $start_date = $startDate; @endphp
    @php $end_date = $endDate; @endphp
@else
    <!-- Form is not submitted, set default or initial values -->
    {{-- Set a default start date if needed  --}}
    @php $start_date = date('Y-m-01'); @endphp
    {{-- Set a default end date if needed --}}
    @php $end_date = date('Y-m-d');   @endphp
@endif

<!--
<div class="row">

    <div class="col-12">
        <p class="alert alert-dark"> {!! Config::get('constants.fa-circle-exclamation') !!}  We currently display data from the current month days by default. You can utilize the date filter to retrieve data for specific date ranges.</p>
    </div>
</div>
-->
<div class="row mb-5">
    <div class="col-7 card">
        <form action="{{ route('mkt.crm',['projectID'=>Crypt::encryptString($projectID??0)]) }}" method="post">
            @csrf
            <div class="row">
                <!-- From Date -->
                <div class="col-3">
                    <div class="form-group">
                        <label for="start_date">From Date</label>
                        <div class="input-group date" id="datetimepicker1">
                            <input type="date" class="form-control" id="start_date" name="start_date" value="{{ old('start_date', $start_date) }}">
                        </div>
                    </div>
                </div>
                       <div class="col-3">
                    <div class="form-group">
                        <label for="end_date">To Date</label>
                        <div class="input-group date" id="datetimepicker2">
                            <input type="date" class="form-control" id="end_date" name="end_date" value="{{ old('end_date', $end_date) }}">
                        </div>
                    </div>
                   
                </div>

                <!-- Campaign -->
                <div class="col-3">
                    <div class="form-group">
                        <!-- Select Dropdown for UTM Campaigns -->
                        <label for="utm_campaign">Campaign:</label>
                        @php
                            if (isset($utmData['getUniqueUtmValues']['utm_campaigns'])) {
                                $campaigns = $utmData['getUniqueUtmValues']['utm_campaigns'];
                            } else {
                                $campaigns = [];
                            }
                        @endphp
                        <select id="utm_campaign" name="utm_campaign" class="form-select">
                            <option value="">Campaign</option>
                            @foreach ($campaigns as $campaign)
                                <option value="{{ $campaign }}" @if ($campaign == old('utm_campaign', $utm_campaign??'')) selected @endif>{{ $campaign }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <!-- Medium -->
                <div class="col-3">
                    <div class="form-group">
                        <!-- Select Dropdown for UTM Mediums -->
                        <label for="utm_medium">Medium:</label>
                        @php
                            if (isset($utmData['getUniqueUtmValues']['utm_mediums'])) {
                                $mediums = $utmData['getUniqueUtmValues']['utm_mediums'];
                            } else {
                                $mediums = [];
                            }
                        @endphp
                        <select id="utm_medium" name "utm_medium" class="form-select">
                            <option value="">Medium</option>
                            @foreach ($mediums as $medium)
                                <option value="{{ $medium }}" @if ($medium == old('utm_medium', $utm_medium??'')) selected @endif>{{ $medium }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <!-- To Date -->
         

                <!-- Source -->
                <div class="col-3">
                    <div class="form-group">
                        <!-- Select Dropdown for UTM Sources -->
                        <label for="utm_source">UTM Source:</label>
                        @php
                            if (isset($utmData['getUniqueUtmValues']['utm_sources'])) {
                                $sources = $utmData['getUniqueUtmValues']['utm_sources'];
                            } else {
                                $sources = [];
                            }
                        @endphp
                        <select id="utm_source" name="utm_source" class="form-select">
                            <option value="">UTM Source</option>
                            @foreach ($sources as $source)
                                <option value="{{ $source }}" @if ($source == old('utm_source', $utm_source??'')) selected @endif>{{ $source }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <!-- Status -->
                <div class="col-3">
                    <div class="form-group">
                        <!-- Select Dropdown for Statuses -->
                        <label for="filter_status">Select Status:</label>
                        @php
                            if (isset($utmData['getUniqueUtmValues']['statuses'])) {
                                $statuses = $utmData['getUniqueUtmValues']['statuses'];
                            } else {
                                $statuses = [];
                            }
                        @endphp
                        <select id="status" name="status" class="form-select">
                            <option value="">Status</option>
                            @foreach ($statuses as $status)
                                <option value="{{ $status }}" @if ($status == old('status', $status??'')) selected @endif>{{ $status }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                  <div class="col-3">
                  <button type="submit" class="btn btn-primary btn-sm mt-1 mt-4">Search</button>
                 </div>
            </div>
            
           

    
        </form>
    </div>
    
    
            <div class="offset-md-1 col-4  card">
            <label for="Status">Statistics for Medium</label>
            <div class="row mt-4">
            @foreach ($leadCount_source as $lead)
            <div class="col-12">
            <div class="mr-4 mb-4">
            @if ($lead['utm_source'] === 'Google')
            <i class="fa-brands fa-square-google-plus fa-2xl" style="color: #db4437;"></i> {{ $lead['lead_count'] }} leads
            @elseif ($lead['utm_source'] === 'Facebook')
            <i class="fa-brands fa-square-facebook fa-2xl" style="color: #4267b2;"></i> {{ $lead['lead_count'] }} leads
            
            @elseif ($lead['utm_source'] === 'Twitter')
            <i class="fa-brands fa-square-twitter fa-2xl" style="color: #1da1f2;"></i> {{ $lead['lead_count'] }} leads
            @elseif ($lead['utm_source'] === 'LinkedIn')
            <i class="fa-brands fa-linkedin fa-2xl" style="color: #0072b1;"></i> {{ $lead['lead_count'] }} leads
            @elseif ($lead['utm_source'] === 'Website')
            <i class="fa-brands fa-wpforms fa-flip-horizontal fa-2xl" style="color: #144aa9;"></i> {{ $lead['lead_count'] }} leads
            @else
            @endif
            </div>
            </div>
            @endforeach
            </div>
            </div>

</div>
