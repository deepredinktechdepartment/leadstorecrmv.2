<div class="row ">
    <div class="col-lg-12 mb-2">
            <a href="{{ url( 'api-credentials/create/'.Crypt::encryptString($projectID??0) ) }}" class="pull-right">
            <u><i class="fa-solid fa-star-half-stroke"></i>Update API Key</u>
            </a>
    </div>
</div>