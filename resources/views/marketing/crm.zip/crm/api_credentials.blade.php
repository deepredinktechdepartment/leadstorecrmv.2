@extends('template_v2')
@section('title', $pageTitle??'')
@section('content')

{{-- Create leads actions items --}}
@include("marketing.crm.leads_actionsitems")


<div class="row">
    <div class="col-5 card ">


        <form method="POST" action="{{ route('store.api_credentials') }}">
            @csrf

            <div class="form-group">
                <label for="merchant_id" class="text text-dark">Setting up an account for the project: {{ Str::title($Project->short_name) }}</label>

            </div>
            <div class="form-group">
                <label for="merchant_id">Merchant ID:</label>
                <input type="text" name="merchant_id" id="merchant_id" class="form-control" value="{{ $ApiCredential->merchant_id??'' }}">
            </div>
            <div class="form-group">
                <label for="api_key">API Key:</label>
                <input type="text" name="api_key" id="api_key" class="form-control" value="{{ $ApiCredential->api_key??'' }}">
            </div>
            <!-- Add other form fields as needed -->
            <button type="submit" class="btn btn-primary">Save</button>
            <input type="hidden" name="project" value="{{ $Project->id??0 }}" />
        </form>


</div>
<div class="col-1">
</div>
<div class="col-6 card">
<h4 class="mb-4">Instructions for Setting Up Your Account</h4>


<ul>
    <li><strong>Step 1:</strong> Log In to Your Leadstore Account. <a class="text text-danger" href="https://leadstore.in/" target="_new"><u>Click here</u></a></li>
    <li><strong>Step 2:</strong> Access API Settings</li>
    <li><strong>Step 3:</strong> Create a New API Application</li>
    <li><strong>Step 4:</strong> Provide Application Details</li>
    <li><strong>Step 5:</strong> Generate API Credentials</li>
    <li><strong>Step 6:</strong> Retrieve API Key and Secret</li>
    <li><strong>Step 7:</strong> Implement in Your Application</li>
    <li><strong>Step 8:</strong> Monitor and Maintain</li>
    <li><strong>Step 9:</strong> Train Your Team on CRM Usage</li>
    <li><strong>Step 10:</strong> Monitor and Analyze CRM Performance</li>
    <li><strong>Step 11:</strong> Continuously Improve and Update Your CRM</li>
    <li><strong>Step 12:</strong> <a class="text text-danger" href="https://api-key.me/index" target="_new"><u>Api-Key Generator Tool</u></a></li>
    <li><strong>Step 13:</strong> The <strong>"Merchant ID"</strong> corresponds to the client's primary key in the lead store database</li>
</ul>



</div>


</div>





@endsection
@push('scripts')



@endpush