@extends('layouts.app')
@section('content')
    <h1>Page Under Construction</h1>
    @endsection