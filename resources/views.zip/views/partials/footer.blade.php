<footer class="bg-dark py-3 mt-5">
    <div class="container">
        <div class="d-flex justify-content-between">
            <p class="m-0 p-0">© Deep Red Ink Consulting Pvt. Ltd.</p>
            <img src="assets/images/leadstore-logo-white.png" alt="leadstore logo" class="img-fluid" />
        </div>
    </div>
</footer>
